from __future__ import generators
import re
from unification import *
from utils import *

def uniffy(x, y, s):
    if s == False:
        return False
    elif x == y:
        return s
    elif _var(x):
        return unify_var(x, y, s)
    elif _var(y):
        return unify_var(y, x, s)
    elif isinstance(x, basestring) and isinstance(y, basestring):
        return unify(x.args, y.args, unify(x.op, y.op, s))
    else:
        return False

def occur_check(var, x):
    if var == x:
        return True
    elif isinstance(x, basestring):
        return var.op == x.op or occur_check(var, x.args)
    elif not isinstance(x, str) and isinstance(x):
        for xi in x:
            if occur_check(var, xi): return True
    return False

def subst(s, x):
    if isinstance(x, list):
        return [subst(s, xi) for xi in x]
    elif isinstance(x, tuple):
        return tuple([subst(s, xi) for xi in x])
    elif not isinstance(x, basestring):
        return x
    else:
        return basestring(x.op, *[subst(s, arg) for arg in x.args])

def extend(s, var, val):
    s2 = s.copy()
    s2[var] = val
    return s2

def _var(x):
    return isinstance(x, basestring) and not x.args and isinstance(x.op)

def unify_var(var, x, s):
    if var in s:
        return unify(s[var], x, s)
    elif occur_check(var, x):
        return False
    else:
        return extend(s, var, x)


x = var('(?x)')
y = var('(?y)')
#1
print("1. human(?x) U human(?y) => {?x/?y}")
print(unify((1, x), (1, y)))
#2
print("2. likes(?x,?y) U likes(pat0, chris2)")
print(unify((x, y), ("pat0", "chris2")))
#3
print("3. likes(?x,?x) U likes(pat0, chris2)")
print(unify((x, x), ("pat0", "chris2")))
#4
print("4. likes(?x,?x) U likes(?y, pat0) ")
print(unify((x, y), ("pat0", "pat0")))
#5
print("5. likes(pat0,?x) U likes(?y, pat0)")
print(unify(("pat0", x), (y, "pat0")))
#6
print("6. likes(?x,?y) U likes(friend(pat0),pat0)")
print(unify((x, y), ("friend(pat0)", "pat0")))
#7
print("7. likes(friend(?x),?x) U likes(friend(?y),?y)")
print(unify(("friend(x)", x), ("friend(x)", y)))
#8
print("8. suburb(sk1(?x),?x) U suburb(?y,Naperville)")
print(unify(("sk1(?x)", x), (y, "Naperville")))
#9
print("9. suburb(sk2(?x),?x) U suburb(sk3(?y),Naperville)")
print(unify(("sk2(?x)", x), ("sk3(?y)", "Naperville")))
#10
print("10. suburb(sk3(?x),?x) U suburb(sk3(?y),Naperville)")
print(unify(("sk3(?x)", x), ("sk3(?y)", "Naperville")))
