#DFS Search
class DepthSearch:
    def dfsSuccessors(self, startState):
        exploredStates = []
        queue = [startState]

        while queue:
            node = queue.pop(0)
            if node not in exploredStates:
                exploredStates.append(node)
                neighbors = self[node]

                for neighbor in neighbors:
                    queue.append(neighbor)
        return exploredStates

    def dfs(self, startState, endState):
        exploredStates = []
        queue = [[startState]]

        if startState == endState:
            return "Your start state is the same as your goal state"

        while queue:
            path = queue.pop(0)
            node = path[-1]
            if node not in exploredStates:
                neighbours = self[node]
                for neighbor in neighbours:
                    new_path = list(path)
                    new_path.append(neighbor)
                    queue.append(new_path)
                    if neighbor == endState:
                        return new_path

                exploredStates.append(node)

    if __name__ == '__main__':
        graph = {'r, o, b': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'b, r, o': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'b, o, r': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'o, b, r': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'o, r, b': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'r, b, o': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                             'b, ro', 'ro, b'],
                 'ob, r': ['o, b, r', 'rob'],
                 'r, ob': ['r, b, o', 'rob'],
                 'bo, r': ['b, o, r', 'rbo'],
                 'r, bo': ['r, o, b', 'rbo'],
                 'rb, o': ['r, b, o', 'orb'],
                 'o, rb': ['o, b, r', 'orb'],
                 'br, o': ['b, r, o', 'obr'],
                 'o, br': ['o, r, b', 'obr'],
                 'or, b': ['o, r, b', 'bor'],
                 'b, or': ['b, r, o', 'bor'],
                 'ro, b': ['r, o, b', 'bro'],
                 'b, ro': ['b, o, r', 'bro'],
                 'rob': ['r, ob'],
                 'orb': ['o, rb'],
                 'bro': ['b, ro'],
                 'rbo': ['r, bo'],
                 'bor': ['b, or'],
                 'obr': ['o, br'],
                 }

        startState = input("Please input your start state ")
        endState = input("Please input your end state")

        print("\nHere's the nodes of the graph visited by depth-first "
              "search, starting from node '': ", dfsSuccessors(graph, startState))

        print("\nHere's the path between the start state and end state:", dfs(graph, startState, endState))