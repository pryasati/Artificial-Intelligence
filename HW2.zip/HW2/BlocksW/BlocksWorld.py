#BFS Search
class breadthSearch:
    def bfsSuccessors(graph, startState):
        exploredStates = []
        queue = [startState]
        while queue:
            node = queue.pop(0)
            if node not in exploredStates:
                exploredStates.append(node)
                neighbors = graph[node]
                for neighbor in neighbors:
                     queue.append(neighbor)
        return exploredStates


    def bfs(graph, startState, endState):
        exploredStates = []
        queue = [[startState]]

        if startState == endState:
            return "Your start state is the same as your goal state"

        while queue:
            path = queue.pop(0)
            node = path[-1]
            if node not in exploredStates:
                neighbours = graph[node]

                for neighbor in neighbours:
                    new_path = list(path)
                    new_path.append(neighbor)
                    queue.append(new_path)
                    if neighbor == endState:
                        return new_path

                exploredStates.append(node)


        return "This is impossible, you will never reach this line"


    if __name__ == '__main__':
        graph = {'r, o, b': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'b, r, o': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'b, o, r': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'o, b, r': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'o, r, b': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'r, b, o': ['r, ob', 'ob, r', 'bo, r', 'r, bo', 'rb, o', 'o, rb', 'br, o', 'o, br', 'or, b', 'b, or',
                            'b, ro', 'ro, b'],
                'ob, r': ['o, b, r', 'rob'],
                'r, ob': ['r, b, o', 'rob'],
                'bo, r': ['b, o, r', 'rbo'],
                'r, bo': ['r, o, b', 'rbo'],
                'rb, o': ['r, b, o', 'orb'],
                'o, rb': ['o, b, r', 'orb'],
                'br, o': ['b, r, o', 'obr'],
                'o, br': ['o, r, b', 'obr'],
                'or, b': ['o, r, b', 'bor'],
                'b, or': ['b, r, o', 'bor'],
                'ro, b': ['r, o, b', 'bro'],
                'b, ro': ['b, o, r', 'bro'],
                'rob': ['r, ob', 'ob, r'],
                'orb': ['o, rb', 'rb, o'],
                'bro': ['b, ro', 'ro, b'],
                'rbo': ['r, bo', 'bo, r'],
                'bor': ['b, or', 'or, b'],
                'obr': ['o, br', 'br, o'],
                }
        states = {'r, o, b': 0, "b, r, o": 0, "b, o, r": 0, "o, b, r": 0, "o, r, b": 0,
                "r, b, o": 0, "ob, r": 1, "r, ob": 1, "bo, r": 2, "r, bo": 2, "rb, o": 3,
                "o, rb": 3, "br, o": 4, "o, br": 4, "or, b": 5, "b, or": 5, "b, ro": 6,
                "ro, b": 6, 'rob': 7, "orb": 8, "bro": 9, "rbo": 10, "bor": 11, "obr": 12}

        neighbors = {0: [4, 6, 5, 3, 2, 1], 4: [9, 0], 6: [7, 0], 5: [8, 0], 3: [0, 10],
                    2: [0, 11], 1: [0, 12], 9: [4], 7: [6], 8: [5], 10: [3], 11: [2], 12: [1]}


        startState = input("Please input your start state ")
        endState = input("Please input your end state")
        print("\nHere's the states of the potential states visited by best-first:", bfs(graph, startState, endState))
        #print("\nHere's the states of the potential states visited by breadth-first "
        #"search, starting from the start '': ", bfsSuccessors(graph, startState))


        print("\nHere's the path between the start state and end state:", bfs(graph, startState, endState))