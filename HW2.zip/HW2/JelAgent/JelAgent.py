import math
from collections import defaultdict

class JealousAgent():
    def __init__(self, agentsLeft, actorsLeft, boat, agentsRight, actorsRight):
        self.agentsLeft = agentsLeft
        self.actorsLeft = actorsLeft
        self.boat = boat
        self.agentsRight = agentsRight
        self.actorsRight = actorsRight
        self.parent = None

    def goal(self):
        if self.agentsRight == 3 and self.actorsRight == 3:
            return True
        else:
            return False

    def valid(self):
        if self.actorsLeft >= 0 and self.actorsRight >= 0 \
                   and self.agentsLeft >= 0 and self.agentsRight >= 0 \
                   and (self.actorsLeft == 0 or self.actorsLeft >= self.agentsLeft) \
                   and (self.actorsRight == 0 or self.actorsRight >= self.agentsRight):
            return True
        else:
            return False

    def __eq__(self, other):
        return self.agentsLeft == other.agentsLeft and self.actorsLeft == other.actorsLeft \
                   and self.boat == other.boat and self.agentsRight == other.agentsRight \
                   and self.actorsRight == other.actorsRight

    def __hash__(self):
        return hash((self.agentsLeft, self.actorsLeft, self.boat, self.agentsRight, self.actorsRight))

def successors(currentState):
    children = [];
    if currentState.boat == 'left':
        new_state = JealousAgent(currentState.agentsLeft, currentState.actorsLeft - 2, 'right',
                                  currentState.agentsRight, currentState.actorsRight + 2)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft - 2, currentState.actorsLeft, 'right',
                                  currentState.agentsRight + 2, currentState.actorsRight)


        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft - 1, currentState.actorsLeft - 1, 'right',
                                  currentState.agentsRight + 1, currentState.actorsRight + 1)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft, currentState.actorsLeft - 1, 'right',
                                  currentState.agentsRight, currentState.actorsRight + 1)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft - 1, currentState.actorsLeft, 'right',
                                  currentState.agentsRight + 1, currentState.actorsRight)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
    else:
        new_state = JealousAgent(currentState.agentsLeft, currentState.actorsLeft + 2, 'left',
                                  currentState.agentsRight, currentState.actorsRight - 2)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft + 2, currentState.actorsLeft, 'left',
                                  currentState.agentsRight - 2, currentState.actorsRight)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft + 1, currentState.actorsLeft + 1, 'left',
                                  currentState.agentsRight - 1, currentState.actorsRight - 1)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft, currentState.actorsLeft + 1, 'left',
                                  currentState.agentsRight, currentState.actorsRight - 1)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
        new_state = JealousAgent(currentState.agentsLeft + 1, currentState.actorsLeft, 'left',
                                  currentState.agentsRight - 1, currentState.actorsRight)

        if new_state.valid():
            new_state.parent = currentState
            children.append(new_state)
    return children

def breathFirstSearch():
    initial_state = JealousAgent(3,3,'left',0,0)
    if initial_state.goal():
        return initial_state
    frontier = list()
    explored = set()
    frontier.append(initial_state)
    while frontier:
        state = frontier.pop(0)
        if state.goal():
            return state
        explored.add(state)
        children = successors(state)
        for child in children:
            if (child not in explored) or (child not in frontier):
                frontier.append(child)
    return None

def debthFirstSearch():
    initial_state = JealousAgent(3,3,'left',0,0)
    if initial_state.goal():
        return initial_state
    frontier = list()
    explored = set()
    frontier.append(initial_state)
    while frontier:
        state = frontier.pop(0)
        if state.goal():
            return state
        explored.add(state)
        parent = successors(parent)
        for parr in parent:
            if (parr not in explored) or (parr not in frontier):
                frontier.append(parr)
    return None



def print_solution(solution):
        path = []
        path.append(solution)
        parent = solution.parent
        while parent:
            path.append(parent)
            parent = parent.parent

        for t in range(len(path)):
            state = path[len(path) - t - 1]
            print("(" + str(state.agentsLeft) + "," + str(state.actorsLeft) \
                              + "," + state.boat + "," + str(state.agentsRight) + "," + \
                              str(state.actorsRight) + ")")

def main():
    method = breathFirstSearch()
    print("All aboard!:")
    print_solution(method)

if __name__ == "__main__":
    main()